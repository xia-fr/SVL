#include "LinearSystem.hpp"
#include "Definitions.hpp"
#include "Profiler.hpp"

//Default Constructor.
LinearSystem::LinearSystem(){
    //Does nothing.
}

//Virtual destructor.
LinearSystem::~LinearSystem(){
    //Does nothing.
}
